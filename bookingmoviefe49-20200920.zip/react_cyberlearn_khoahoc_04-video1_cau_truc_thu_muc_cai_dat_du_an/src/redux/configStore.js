import {combineReducers, createStore} from 'redux';





const rootReducer = combineReducers({
    //reducer khai báo tại đây
})



const store = createStore(rootReducer);




export default store;

